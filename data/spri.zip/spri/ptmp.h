// header file for sprite sheet. AUTO GENERATED, do not edit
// 
// source PCX: ../ptmp.pcx
// sheet script: ptmp.sht
// palette file: ptmp.pal

#define _ptmp_PRSBFCW0 10U
#define _ptmp_PRSBFCW1 11U
#define _ptmp_PRSBFCW2 12U
#define _ptmp_PRSBLCW0 20U
#define _ptmp_PRSBLCW1 21U
#define _ptmp_PRSBLCW2 22U
#define _ptmp_PRSBRCW0 30U
#define _ptmp_PRSBRCW1 31U
#define _ptmp_PRSBRCW2 32U
#define _ptmp_PRSBACW0 40U
#define _ptmp_PRSBACW1 41U
#define _ptmp_PRSBACW2 42U

// end list
