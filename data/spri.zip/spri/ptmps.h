// header file for sprite sheet. AUTO GENERATED, do not edit
// 
// sheet script: ptmp.sht

// sprite sheet (sprite IDs)
#define _ptmp_PRSBFCW0_sprite 10U
#define _ptmp_PRSBFCW1_sprite 11U
#define _ptmp_PRSBFCW2_sprite 12U
#define _ptmp_PRSBLCW0_sprite 20U
#define _ptmp_PRSBLCW1_sprite 21U
#define _ptmp_PRSBLCW2_sprite 22U
#define _ptmp_PRSBRCW0_sprite 30U
#define _ptmp_PRSBRCW1_sprite 31U
#define _ptmp_PRSBRCW2_sprite 32U
#define _ptmp_PRSBACW0_sprite 40U
#define _ptmp_PRSBACW1_sprite 41U
#define _ptmp_PRSBACW2_sprite 42U
// animation list (animation IDs)

// end list
