// header file for sprite sheet. AUTO GENERATED, do not edit
// 
// source PCX: ../chikyuu.pcx
// sheet script: chikyuu.sht
// palette file: chikyuu.pal

#define _chikyuu_CHUBFCW0 10U
#define _chikyuu_CHUBFCW1 11U
#define _chikyuu_CHUBFCW2 12U
#define _chikyuu_CHUBLCW0 20U
#define _chikyuu_CHUBLCW1 21U
#define _chikyuu_CHUBLCW2 22U
#define _chikyuu_CHUBRCW0 30U
#define _chikyuu_CHUBRCW1 31U
#define _chikyuu_CHUBRCW2 32U
#define _chikyuu_CHUBACW0 40U
#define _chikyuu_CHUBACW1 41U
#define _chikyuu_CHUBACW2 42U

// end list
