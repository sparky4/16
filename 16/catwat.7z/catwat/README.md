The Catacomb Apocalypse
=======================

This repository contains the source code for The Catacomb Apocalypse. The
source code is designed for Borland C++ 2.0, but compiled fine with Borland C++
3.1 at the time of this release.

It is released under the GNU GPLv2. Please see COPYING for license details.

This release does not affect the licensing for the game data files. You will
need to legally acquire the game data in order to use the exe built from this
source code.

To run the executable, the following command must be used or the check must be
disabled in C6_MAIN.C:
    apocgame.exe ^(a@&r`
