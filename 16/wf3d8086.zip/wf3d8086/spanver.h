//#define SPEAR
#define SPANISH
#define ARTSEXTERN
#define DEMOSEXTERN
//#define MYPROFILE
//#define DEBCHECK
#define CARMACIZED
//#define UPLOAD
