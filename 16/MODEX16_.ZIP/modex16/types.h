/*
 * Just some handy typedefs that make it easier to think about the low
 * level code
 */

typedef unsigned char byte;
typedef unsigned short word;
typedef unsigned long  dword;
typedef signed char sbyte;
typedef signed short sword;
typedef signed long sdword;
