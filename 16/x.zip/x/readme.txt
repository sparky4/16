ModeX - A graphical library for DOS programs
Copyright (c) 1993-1994 Alessandro Scotti
http://www.ascotti.org/

Please look at the above site in the "Art of..." and
then in the "Old programs" section for more information.


